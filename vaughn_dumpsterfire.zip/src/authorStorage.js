// This is a file that contains lists of authors by genre
const fantasy = [
  'Tolkein',
  'Brandon Sanderson',
  'Robert Jordan',
  'Terry Pratchett',
  'Patrick Rothfuss',
  'Ray Bradbury',
  'Ursula Le Guin',
  'Joe Abercrombie',
  'David Eddits',
  'Robin Hobb',
  'Homer',
  'Lovecraft',
  'Niel Gaiman',
  'Stephen King',
  'Terry Brooks',
  'Anne McCaffrery',
  'Jim Butcher',
  'Raymond Feist',
  'Rick Riordan',
  'Steven Erikson',
  'George Martin',
  'Rowling',
];

const scifi = [
  'Arthur Clark',
  'Jules Verne',
  'Isaac Asimov',
  'Robert Heinlein',
  'Ray Bradbury',
  'Wells',
  'Douglas Adams',
  'Phillip Dick',
  'Frank Herbert',
  'George Orwell',
  'Larry Niven',
  'Andre Norton',

];

module.exports = {
  fantasy,
  scifi,
};
