const key = 'dDQJu586sfJXa97ntSTw';

module.exports = {
  key,
};
