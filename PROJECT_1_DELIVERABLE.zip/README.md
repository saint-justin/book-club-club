# Book Club Club

Book club club is a site dedicated to the dedicated fans of book clubs. It's a simple site that lets users post up times, dates, and links to their book club's meetings. This is a platform for anyone who loves to read anything from fantasy to non-fiction biographies to manga any anything inbetween.
